## Infection example

- Layout.save: layout file that can be loaded in PlateEditor.
- Result.xlsx: excel file containing the results. The file can be mapped with a Well ID ("Well"). The "Data" column should be imported as a numeric type.

Use the "Column Analysis" tool to aggregate the values for each combination.

Note: the data in the result file were randomly generated.
