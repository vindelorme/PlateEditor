## Simple example

- Layout.save: layout file that can be loaded in PlateEditor.
- Results_example1.txt: text file containing the data for this plate. The file can be mapped with a Well ID ("Well"). The "Cell count" column should be imported as a numeric type.

Note: the data in the result file are results from real-world experiments
