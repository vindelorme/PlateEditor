## DRC example

- Layout.save: layout file that can be loaded in PlateEditor.
- Result.csv: csv file containing the results. The file can be mapped with a Well ID ("Well"). The "Data" column should be imported as a numeric type.

Use the "Grouped Analysis" tool to aggregate the values for each compound. The concentration data can be added as rows and the range "compounds" added as columns.

Note: the data in the result file were selected from real-world experiments
